from tkinter import * 
from tkinter.ttk import *
from PIL import ImageTk,Image
import random
import time

first = True

root = Tk()

hipsters_img=(Image.open("hipsters.gif"))
hipsters_img_rs = hipsters_img.resize((150, 150), Image.ANTIALIAS)
new_hipsters_img= ImageTk.PhotoImage(hipsters_img_rs)

speedsters_img=(Image.open("speedsters.gif"))
speedsters_img_rs = speedsters_img.resize((150, 150), Image.ANTIALIAS)
new_speedsters_img= ImageTk.PhotoImage(speedsters_img_rs)

shadows_img=(Image.open("shadows.gif"))
shadows_img_rs = shadows_img.resize((150, 150), Image.ANTIALIAS)
new_shadows_img = ImageTk.PhotoImage(shadows_img_rs)

engineers_img=(Image.open("engineers.gif"))
engineers_img_rs = engineers_img.resize((150, 150), Image.ANTIALIAS)
new_engineers_img = ImageTk.PhotoImage(engineers_img_rs)

all_houses_img=(Image.open("houses.jpg"))
all_houses_img_rs = all_houses_img.resize((150, 150), Image.ANTIALIAS)
new_all_houses_img = ImageTk.PhotoImage(all_houses_img_rs)

ds_logo_img=(Image.open("ds_logo.png"))
ds_logo_img_rs = ds_logo_img.resize((150, 150), Image.ANTIALIAS)
new_ds_logo_img = ImageTk.PhotoImage(ds_logo_img_rs)

blank_img=(Image.open("blank.jpg"))
blank_img_rs = blank_img.resize((150, 150), Image.ANTIALIAS)
new_blank_img= ImageTk.PhotoImage(blank_img_rs)

images = [new_hipsters_img,new_hipsters_img,new_speedsters_img,new_speedsters_img,
          new_shadows_img, new_shadows_img, new_engineers_img, new_engineers_img,
          new_all_houses_img, new_all_houses_img, new_ds_logo_img, new_ds_logo_img]

random.shuffle(images)

buttons = {}

button_images = {}

  

for x in range(4):
    for y in range(3):
         button = Button(root, image = new_blank_img, command=lambda x=x, y=y: flipImage(x, y))
         button.grid(column=x, row=y)
         buttons[x, y] = button
         button_images[x, y] = images.pop()



def flipImage(x, y):
    global first
    global previousX, previousY
    buttons[x, y]['image'] = button_images[x, y]
    buttons[x, y].update_idletasks()

    if first:
        previousX = x
        previousY = y
        first = False
    elif previousX != x or previousY != y:
        if buttons[previousX, previousY]['image'] != buttons[x, y]['image']:
            time.sleep(0.5)
            buttons[previousX, previousY]['image'] = new_blank_img
            buttons[x, y]['image'] = new_blank_img
        else:
            buttons[previousX, previousY]['command'] = DISABLED
            buttons[x, y]['command'] = DISABLED
        first = True
         

root.mainloop()


