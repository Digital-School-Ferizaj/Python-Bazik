import turtle

turtle.bgcolor("black")
t=turtle.Turtle()
t.shape("classic") #square, arrow, circle, turtle, triangle, classic

t.pencolor("white")
t.speed(10)

t.pensize(5)

# forward, backward, left, right
# fd, bk, lt, rt

"""
t.fd(200)
t.lt(90)
t.bk(200)
t.lt(45)
t.fd(283)


t.goto(100,100)
t.goto(0,0)


i=0
while i<360:
    t.fd(1)
    t.lt(1)
    i+=1


"""
t.fillcolor("red")

t.begin_fill()

t.circle(60)

t.end_fill()

#rreth
t.fillcolor("yellow")

t.begin_fill()

t.lt(180)
t.circle(60)

t.end_fill()

#katrori
t.pen(speed=10, pencolor="purple", pensize=5)

t.penup()
t.goto(200,200)
t.pendown()

t.begin_fill()
for i in range(4):
    t.fd(80)
    t.rt(90)
t.end_fill()

#ylli
t.pen(speed=10, pencolor="orange", pensize=2)
t.fillcolor("lime")

t.penup()
t.goto(-200,-200)
t.pendown()

t.begin_fill()

for i in range(5):
    t.fd(100)
    t.lt(144)
    
t.end_fill()






