import turtle

turtle.bgcolor("black")
t=turtle.Turtle()

t.pencolor("white")

t.shape("turtle") #square, arrow, circle, turtle, triangle, classic

t.pensize(5)
t.speed(10)

# forward,  backward,   left,   right
# fd,       bk,         lt,     rt

"""
t.fd(200)
t.lt(90)
t.bk(200)


t.goto(100, 100)
t.goto(-100, 100)
t.goto(0,0)

i=0
while i< 360:
    t.fd(1)
    t.lt(1)
    i+=1
"""

#rrethi 1
t.fillcolor("red")
t.begin_fill()

t.circle(200)
t.lt(180)

t.end_fill()

#rrethi 2
t.fillcolor("orange")
t.pencolor("aqua")

t.begin_fill()

t.circle(100)

t.end_fill()

#katrori
t.penup()
t.goto(-200,-100)
t.pendown()

t.begin_fill()
for i in range(4):
    t.fd(80)
    t.rt(90)
t.end_fill()

#ylli
t.pen(speed=10, pencolor="orange", pensize=2)
t.fillcolor("lime")

t.penup()
t.goto(300,-100)
t.pendown()

t.begin_fill()

for i in range(5):
    t.fd(100)
    t.lt(144)
    
t.end_fill()





