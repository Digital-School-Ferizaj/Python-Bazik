name = "Lirak"  #variabla name
surname = "Hamiti" #komenti
print(name, surname)

numri = 5*6

'''
komenti me disa rreshta
komenti me disa rreshta
'''

age = "?"

"""
komenti me disa rreshta
"""

print(numri)

#Integer:
x1 = int(1)   # x will be 1
y1 = int(2.8) # y will be 2
z1 = int("3") # z will be 3

#Float:
x = float(1)    # x will be 1.0
y = float(2.8)  # y will be 2.8
z = float("3")  # z will be 3.0
w = float("4.2")# w will be 4.2

"hello" == 'hello'

print(z)

message = "Ky eshte mesazhi im"

print( len(message) )


score = 100
message = "Your score is %s, try again!"
print(message % score)

kurset = ["Code", "Scratch", "api", "HTML", "JAVA", "python"]

print(kurset[0])

message = "I love %s"
print(  message % kurset[ len(kurset) -1 ]  )

message = "I love %s"
print(  message % (kurset[0] + " and " + kurset[1]) )

