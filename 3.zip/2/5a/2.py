






print("Lesson 2 - Variables \n")


#komenti

"""
komenti me shum rreshta

Variables can contain letters, underline(_), numbers 

Symbols such as -, /, #, or @ aren’t allowed.

Variables cannot start with a number. One variable can be called message1 but not 1message

No spaces allowed.

Avoid keywords that are reserved for Python example: “print”

"""

emri = "Lirak" # <-- ky eshte emiri
fundi = 10

print(emri)
print(emri, fundi)


#Integer:
x = int(1) # x will be 1
y = int(2.8) # y will be 2
z = int("3") # z will be 3

#Float:
x = float(1) # x will be 1.0
y = float(2.8) # y will be 2.8
z = float("3") # z will be 3.0
w = float("4.2") # w will be 4.2


money = 25
food = 5
days = 5

print((money - food) / days)

m = (money - food) / days
print(m)


'hello' == "hello"

mesazhi = "Pershendetje te gjithe"

print( len(mesazhi) )


score = 20
message = "Your score is %s, try again!"

print (message % score)

mesazhi = "I love %s, what about you?"
kursi1 = "python"
kursi2 = "php"

print(mesazhi % kursi1)
print(mesazhi % kursi2)
print(mesazhi % "java")





