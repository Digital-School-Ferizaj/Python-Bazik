from tkinter import Tk, simpledialog, messagebox

#check if number is even or odd
def is_even(number):
    return number % 2 == 0

""" Encrypt """

#function that will get the letters in even
#position and add them to a list
def get_even_letters(message):
    even_letters = []
    for counter in range(0, len(message)):
        if is_even(counter):
            even_letters.append(message[counter])
    return even_letters

#function that will get the letters in odd
#position and add them to a list
def get_odd_letters(message):
    odd_letters = []
    for counter in range(0, len(message)):
        if not is_even(counter):
            odd_letters.append(message[counter])
    return odd_letters

""" Decrypt """
def get_even_letters_dec(message):
    even_letters_dec = []
    for counter in range(0, int(len(message)/2)):
        even_letters_dec.append(message[counter])
    return even_letters_dec

def get_odd_letters_dec(message):
    odd_letters_dec = []
    for counter in range(int(len(message)/2), len(message)):
        odd_letters_dec.append(message[counter])
    return odd_letters_dec


#this function checks if the letters is vowel
def is_vowel(letter):
    if (letter == "A" or
        letter == "E" or
        letter == "I" or
        letter == "O" or
        letter == "U" or
        letter == "Y" or
        letter == "a" or
        letter == "e" or
        letter == "i" or
        letter == "o" or
        letter == "u" or
        letter == "y"):
        return True


""" The function that will do the actual Encryption """

def encrypt(message):
    letter_list = []

    if not is_even(len(message)):
        message = message + " "

    even_letter = get_even_letters(message)
    odd_letter = get_odd_letters(message)

    #add the odd letters at the begining
    #also add a dot(.) if the letter is vowel
    for counter in range(0, int(len(message)/2)):
        letter_list.append(odd_letter[counter])
        if (is_vowel(odd_letter[counter]) == True):
            letter_list.append(".")

    for counter in range(0, int(len(message)/2)):
        letter_list.append(even_letter[counter])
        if (is_vowel(even_letter[counter]) == True):
            letter_list.append(".")

    new_message = "".join(letter_list)
    reversed_encrypted_message = "".join(reversed(new_message))

    return reversed_encrypted_message


""" The function that will do the actual Decryption """

def decrypt(message):
    letter_list = []

    unreversed_message = "".join(reversed(message))

    if not is_even(len(unreversed_message)):
        unreversed_message = unreversed_message + " "

    reversed_message = unreversed_message.replace(".", "")

    even_letters = get_even_letters_dec(reversed_message)
    odd_letters = get_odd_letters_dec(reversed_message)

    for counter in range(0, int(len(reversed_message)/2)):
        letter_list.append(odd_letters[counter])
        letter_list.append(even_letters[counter])

    new_message = "".join(letter_list)

    return new_message


"""app logic"""

def get_task():
    task = simpledialog.askstring("Task", "Do you want to encrypt or decrypt?")
    return task

def get_message():
    message = simpledialog.askstring("Message", "what is your secrete message?")
    return message

root = Tk()
root.withdraw()

while True:
    task = get_task()
    if task == "encrypt":
        message = get_message()
        encrypted = encrypt(message)
        messagebox.showinfo("Cipertext of the secret message is: ", encrypted)
        print(encrypted)
    elif task == "decrypt":
        message = get_message()
        decrypted = decrypt(message)
        messagebox.showinfo("Plaintext of the secret message is: ", decrypted)
    else:
        break
    
















