print("Lesson 6 - Quiz")

score = 0

def check_question(guess, answer, answer2):
    global score
    guessing = True
    attempt = 1
    while guessing and attempt < 4:
        if guess.lower() == answer.lower() or guess.lower() == answer2.lower():
            print("Correct Answer \n")
            score = score + (4 - attempt)
            guessing = False
        else:
            if attempt < 3:
                guess = input("Wrong answer. Try again.")
            attempt += 1
    if attempt == 4:
        print("The correct answer was: "+ answer +"\n")

question1 = input("What is capital city of Kosovo? \n a)Prishtina \n b)Paris \n c)Berlin \n d)Tirana \n Enter: A, B,C or D \n")           
check_question(question1, "a", "Prishtina")

question2 = input("What is capital city of France? \n a)Prishtina \n b)Paris \n c)Berlin \n d)Tirana \n Enter: A, B,C or D \n")
check_question(question2, "b", "Paris")

question3 = input("What is capital city of Germany?\n a)Prishtina \n b)Paris \n c)Berlin \n d)Tirana \n Enter: A, B,C or D \n")
check_question(question3, "c", "Berlin")

print(score)
