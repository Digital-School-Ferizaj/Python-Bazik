print("Lesson 5 - Functions \n")

def emri_funksionit():
    print("hello from first function")

emri_funksionit()


"""
A parameter is the variable listed inside the parentheses in the function definition.

An argument is a value that is sent to the function when it is called.

"""

def funksioni1(parametri):
    print(parametri)

argumenti = 6
funksioni1(argumenti)


def emri(name):
    print("Pershendetje", name + "! Si je sot?")

emri("Lirak")
emri("Arbes")

def funksioni2(name, msg):
    print(name, msg)

funksioni2("Gent,", "si je?")

def repeat_name(name, num):
    for i in range(0, num):
        print(name)

name = input("Please give us your name:")
n = input("How many times to repeat?")
n = int(n)

repeat_name(name, n)
