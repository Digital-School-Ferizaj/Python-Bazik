print("Lesson 6 - Quiz Game \n")

score = 0

print("Guess the Capital Cities!")


def check_question(guess, answer):
    global score
    guessing = True
    attempt = 0
    while guessing and attempt < 3:
        if guess.lower() == answer.lower():
            print("Correct Answer!")
            score = score + 3 - attempt
            guessing = False
        else:
            if attempt < 2:
                guess = input("Wrong answer. Try again.")
            attempt += 1
    if attempt == 3:
        print("Wrong Answer. The correct answer was", answer)
    


question1 = input("Kush eshte kryeqyteti i Frances? \n a)parisi \n b)prishtina \n c)ferizaji \n Enter: a,b,c or d")
check_question(question1, "a")

question2 = input("Kush eshte kryeqyteti i Kosoves?")
check_question(question2, "Prishtina")

question3 = input("Kush eshte kryeqyteti i Gjermanise?")
check_question(question3, "Berlini")

question4 = input("Kush eshte kryeqyteti i Holandes?")
check_question(question4, "Amsterdam")


print("Your total score is:", score)
