print("Lesson 5 - Functions")

def emriFunksioni(parametri):
    print(parametri)


argumenti = "Nje fjale apo fjali"

emriFunksioni(argumenti)

"""
A parameter is the variable listed inside the parentheses in the function definition.
An argument is a value that is sent to the function when it is called.
"""

def my_function():
    print("inside function")

my_function()

def funksioni(name):
    print("Hello", name)

funksioni("Lirak")
funksioni("Jon")
funksioni("Elsa")

def piketFinale(score):
    print("Ju keni arritur %s pike" % score)

piketFinale("100")

def hi(name, msg):
    print("Hello", name + ", " + msg)

hi("Rrezart", "how are you today?")
hi("Genit", "how was the weekend?")

#hi() <- error
#hi("gent") <- error


def shumzim(x,y):
    shuma = x * y
    return shuma

a = int( input("first number:"))
b = int( input("second number:"))
shuma = shumzim(a, b)
print(shuma)


def repeat_name(name, num):
    for i in range(0, num):
        print(name)

name = input("your name:")
n = int( input("how many times to repeat?"))

repeat_name(name, n)

print( max(2, 5, 6, 7, 3, 5, 9) )

print( min(2, 5, 6, 7, 3, 5, 9) )

v=[2, 5, 6, 7, 3, 5, 9]
print( sum(v) )




