print("Conditionals")

print("Boolean expressions")

type("fjala")   #<-String
type(3)         #<-Integer

#Boolean
type(True)      #<-Boolean
type(False)     #<-Boolean


#Boolean expression
5 == 5

x = 5
y = 5

x == y      # x is equal to y
x != y      # x is not equal to y
x > y       # x is greater than y
x < y       # x is smaller than y
x >= y      # x is greater than or equal to y
x <= y      # x is less than or equal to y
x is y      # x is the same as y
x is not y  # x is not the same as y

x = 5
y = "5"
z = 5.0

x == y      #False
x is y      #False
x == z      #True
x is z      #False
z is not x  #True

print(x is y)      #False
print(x == z)      #True


name = "John"
name == "Elon" #False
name == "John" #True

age = 35

age > 20 #True
age < 30 #False

age > 20 and age < 30 #False


movies = ("Interstellar", "Spiderman", "Barbie", "Frozen")

"Frozen" in movies #True
"Batman" in movies #False

age = 17

if age < 18:
    print("You cannot vote!")
    print("You need to be at least 18 to vote")
else:
    print("You can vote now!")


age = int( input("Sa vjet i ke?") )
if age <= 7:
    print("Tickets are free")
elif age < 15:
    print("50% discount on tickets")
elif age < 18:
    print("20% discount on tickets")
else:
    print("Pay full price")











