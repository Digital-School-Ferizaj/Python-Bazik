print(5 == 5)

print(5 == 6)

x=5.0
y=5

x == y      # x is equal to y
x != y      # x is not equal to y
x > y       # x is greater than y
x < y       # x is smaller than y
x >= y      # x is greater than or equal to y
x <= y      # x is less than or equal to y
x is y      # x is the same as y
x is not y  # x is not the same as y

z = (3 is "3")
print(z)

print("---")

x = 5
y = "5"
z = 5.0

print(x == y)      #False
print(x is y)      #False
print(x == z)      #True
print(x is z)      #False
print(z is not x)  #True

print("---")

age = int(input("How old are you?"))

if age < 16:
    print("You are to young to vote!")
elif age < 18:
    print("Get ready to vote in few years!")
else:
    print("Go check your voting place!")


print("outside of the condition!")


"""
for(i=0,i<10,i++){
    }

"""

pro_lang = ["python", "Java", "php"]

for x in pro_lang:
    print(x)


for y in range(5):
    print(y)

for counter in range(3, 11):
    print("Digital School ", counter)

for z in range(2, 20, 3):
    print(z)

for x in "Tomato":
    print(x)

vege = ["tomato", "garlic", "potato"]

for z in vege:
        print(z)
        if z == "garlic":
            break

for z in vege:
        if z == "garlic":
            break
        print(z)

i=1
while i < 6:
    print(i)
    i = i + 1
    if i == 4:
        break

print("--")

i = 0
while i < 5:
    i+=1
    if i == 3:
        continue
    print(i)
else:
    print("i is no longer less than 5")


n = int(input("Enter number: "))
sum = 0
i = 1

while i < n:
    sum = sum + i
    i+=1

print("The sum is ", sum)










