from tkinter import Tk, simpledialog, messagebox

def get_events():
    list_events = []
    with open("euro_results.txt") as file:
        for line in file:
            line = line.rstrip("\n")
            current_event = line.split("/")
            list_events.append(current_event)
    return list_events

def write_to_file(year, countries, score):
    with open("euro_results.txt", "a") as file:
        file.write("\n" + year + "/" + countries + "/" + score)

root = Tk()
root.withdraw()


events = get_events()

query_year = simpledialog.askstring("year", "type the year:")

knowAnswer = False

#app logic
for event in events:
    event_year = event[0]
    if event_year == query_year:
        knowAnswer = True
        countries = event[1]
        score = event[2]
        messagebox.showinfo("Answer", "The score for euro "+ event_year + " was " + countries + ":" + score)
        break

if knowAnswer == False:
    new_countries = simpledialog.askstring("Teach me", "I dont know who were the finalist in euro " + query_year + ". Can you tell me?")
    new_score = simpledialog.askstring("Score", "What was the score?")
    write_to_file(query_year, new_countries, new_score)










