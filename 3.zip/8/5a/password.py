print("Module 8 - Password Generator / import modules")

# import moduli from libraria
import random
import string

colors = ["yellow", "silver", "gold", "blue", "black", "white", "brown"]
shapes = ["circle", "diamond", "triangle", "square", "hexagon"]

while True:
    color = random.choice(colors)
    shape = random.choice(shapes)
    number = random.randrange(0, 100)
    special_char = random.choice(string.punctuation)

    password = color + shape + str(number) + special_char

    print("your password is:", password)
    
    response = input("a do pasword tjeter?")

    if response == "jo":
        break


def generate_password(length):
    letters = string.ascii_letters
    numbers = string.digits
    special_char_all = string.punctuation

    all_characters = letters + numbers + special_char_all

    password = ""
    for i in range(length):
        password += random.choice(all_characters)
    return password

r = int( input("Sa shkronja/numra/karakter i do ne passwordin tend?") )

print(generate_password(r))





    
