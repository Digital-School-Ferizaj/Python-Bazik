import random
import string

#from libraise import moduli

colors = ["yellow", "blue", "green", "purple", "pink"]
shapes = ["circle", "square", "rectangle", "diamond"]

print("Welcome to Password Generator! \n")

while True:
    color = random.choice(colors)
    shape = random.choice(shapes)
    number = random.randrange(0, 100)
    special_char = random.choice(string.punctuation)

    password = color + shape + str(number) + special_char

    print("Your new password is: %s \n" % password)

    response = input("Would you like another password? Type yes or no: ")
    
    if response == "no":
        break



def generate_password(length):
    letters = string.ascii_letters
    digits = string.digits
    special_characters = string.punctuation
    all_characters = letters + digits + special_characters
    password = ""
    for i in range(length):
        password += random.choice(all_characters)
    return password

# Example usage
print(generate_password(8))




