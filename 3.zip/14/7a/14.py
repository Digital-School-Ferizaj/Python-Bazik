print("Module 14 - Layout Managers [place/pack/grid]")

print("place")
    
from tkinter import *
from PIL import Image, ImageTk


"""
Some of the main options that we can use are:

anchor − This option is used to specify the exact position of the widget. The values that we can use are N, E, S, W, NW, SE, or SW. The default value is NW which means that the widget will be positioned in the upper left corner of the parent container.

height, width − This option is used to specify height and width in pixels.

x, y −This option is used to specify the horizontal and vertical offset in pixels.

relheight, relwidth − This option is used to specify the relative width and height of the widget. Values that we can use are between 0.0 and 1.0, and they represent the fraction of the height and width of the parent widget.

relx, rely − This option is used to specify the relative x and y position of the widget. Values that we can use are between 0.0 and 1.0, and they represent the fraction of the height and width of the parent widget.
"""

root = Tk()
root.geometry("800x600")

Label(root, text="Trees", fg="black", font=("Courier", 15)).place(x=170, y=20)
Label(root, text="Ocean", fg="black", font=("Courier", 15)).place(x=570, y=20)
Label(root, text="Mountains", fg="black", font=("Courier", 15)).place(x=170, y=310)
Label(root, text="Sky", fg="black", font=("Courier", 15)).place(x=570, y=310)

#
img1 = (Image.open("img/trees.jpg"))
resized_image1 = img1.resize((300,200), Image.Resampling.LANCZOS)
new_image1 = ImageTk.PhotoImage(resized_image1)

canvas = Canvas(root, width=325, height=225)
canvas.create_image(15, 15, anchor=NW, image = new_image1)
canvas.place(x=50, y=50)


#
img2 = (Image.open("img/ocean.jpg"))
resized_image2 = img2.resize((300,200), Image.Resampling.LANCZOS)
new_image2 = ImageTk.PhotoImage(resized_image2)

canvas = Canvas(root, width=325, height=225)
canvas.create_image(15, 15, anchor=NW, image = new_image2)
canvas.place(x=430, y=50)

#
img3 = (Image.open("img/mountains.jpg"))
resized_image3 = img3.resize((300,200), Image.Resampling.LANCZOS)
new_image3 = ImageTk.PhotoImage(resized_image3)

canvas = Canvas(root, width=325, height=225)
canvas.create_image(15, 15, anchor=NW, image = new_image3)
canvas.place(x=50, y=340)

#
img4 = (Image.open("img/sky.jpg"))
resized_image4 = img4.resize((300,200), Image.Resampling.LANCZOS)
new_image4 = ImageTk.PhotoImage(resized_image4)

canvas = Canvas(root, width=325, height=225)
canvas.create_image(15, 15, anchor=NW, image = new_image4)
canvas.place(x=430, y=340)



root.mainloop()
