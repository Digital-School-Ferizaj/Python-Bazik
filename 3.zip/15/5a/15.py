print("Lesson 15 - grid Layot Manager")

#options we can use in grid() are:
"""
column: It is used to specify the column number where we want to position our widget.

columnspan: It is used to specify the number of columns the widget should occupy.
        With this option, we can expand the widget into multiple cells of a row.

row: It is used to specify the row number where we want to position our widget.

rowspan: It is used to specify the number of columns the widget should occupy.
        With this option, we can expand the widget into multiple cells of a column.

padx & pady (External padding): These options are used to specify the external horizontal and vertical paddings.

ipadx & ipady (Internal padding): These options are used to specify the internal horizontal and vertical paddings.

sticky: It is used to specify in which direction we want the widget to be stuck when the cell is larger than the widget.
        Values that we can use are: N,E,S,W,NE,NW,SE & SW.
"""

import tkinter as tk
from tkinter import ttk, Label, Entry, W, E, EW, Button, Tk
from tkinter import Listbox, Checkbutton, Frame, SINGLE

root = tk.Tk()
root.geometry("700x500")
root.title("Form with grid layot")
root.configure(background="#00014e")
root.resizable(0,0)

#creating main frames
frame1 = Frame(root, bg="#108bf9", width=700, height=50)
frame2 = Frame(root, bg="#00014e", width=700, height=50)
frame3 = Frame(root, bg="#00014e", width=700, height=100)
frame4 = Frame(root, bg="#00014e", width=700, height=200)
frame5 = Frame(root, bg="#00014e", width=700, height=100)

frame1.grid(row=0, sticky=W)
frame2.grid(row=1, sticky=W)
frame3.grid(row=2, sticky=W)
frame4.grid(row=3, sticky=W)
frame5.grid(row=4, sticky=W)

"""
columnconfigure() and rowconfigure() methods
frame1.rowconfigure(0, weight=1)
frame2.rowconfigure(1, weight=4)
"""

#header label
header_label = Label(frame1, text="Summer School registration form", bg="#108bf9", fg="white", font=("Courier",15))
header_label.grid(row=0, column=0, pady=15, padx=180)

#child frames of frame2
frame2_left = Frame(frame2, bg="#00014e", width=350, height=50,padx=56)
frame2_right = Frame(frame2, bg="#00014e", width=350, height=50,padx=20)

frame2_left.grid(row=0, column=0)
frame2_right.grid(row=0, column=1)

#--frame2_left
#name label
name_label = Label(frame2_left, text="Name:", bg="#00014e", fg="white", font=("Arial",10))
name_label.grid(row=0, column=0, pady=30, padx=5)




