print("Lesson 4 - Loops")

#while
#for


prog_lang = ["python", "java", "php"]

for x in prog_lang:
    print(x)
    
print("----")

for count in range(6):
    print("Joni eshte ne humor te mire!", count)

print("----")

for x in range(2, 8):
    print(x)
    
print("----")

for x in range(2, 20, 3):
    print(x)

print("----")

for x in "Tomato":
    print(x)
    
print("----")

veggies = ["Tomato", "Garlic", "Carrots", "Onion"]
for x in veggies:
    if x == "Carrots":
        break
    print(x)

print("----")

for x in veggies:
    print(x)
    if x == "Carrots":
        break

print("----")

i=0
while i < 5:
    print(i)
    i = i + 1 #i += 1

print("----")

i=1
while i<5:
    print(i)
    if i == 3:
        break
    i+=1
    
print("----")

i=0
while i<6:
    i+=1
    if i ==3:
        continue
    print(i)
    
print("----")

i=1
while i<6:
    print(i)
    i+=1
else:
    print("i is no longer less than 6")

print("----")

#Program to add natural numbers
#Sum = 1+2+...+n

#take input
n = int( input("Give me a number: ") )

#initialize sum and counter
sum = 0
i = 1

while i <= n:
    sum = sum + i
    i = i + 1

#print the sum
print("The sum is", sum)




